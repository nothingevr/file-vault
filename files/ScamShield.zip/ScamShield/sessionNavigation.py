scans = []

# This Fucnction Will Append The Scan Result To Session Memory
def push_scan(msg,risk,verdict,date):
  record = {"Message":msg,
            "Risk%":risk,
            "Verdict":verdict,
            "ScanDateTime":date
          }
  scans.append(record)

# This function Will Retrieve and Delete Most Recent Scan Result From Session Memory 
def pop_scan():
  if not is_empty():
    return scans.pop()
  else:
    return {"Output":"No Recent Scan"}

# This function Will Retrieve Most Recent Scan Result From Session Memory
def peek_scan():
  if not is_empty():
    return scans[-1]
  else:
    return {"Output":"No Recent Scan"}

# This Fucntion Will Check Whether Session Memory Is Empty or Not
def is_empty():
  if len(scans) == 0:
    return True
  else:
    return False