from detector  import evaluateMsg, verdict
import datetime
from sessionNavigation import push_scan
from database import insert_scan_log
from utils import cleanMessage

def scanBulk(path):
  try:
    with open(path,'r') as fin, open('ScamMessages.txt','a') as fout:
     # msgs = fin.readlines()
      for i in fin:
        if i.strip():
          i = cleanMessage(i.strip()).lower()
          _, risk, result = evaluateMsg(i.strip())
          
          fout.write(f"[ {datetime.datetime.now().strftime("%y-%b-%d %H:%M:%S")} ]\n")
          fout.write(f"Message: {i.strip()}\n")
          fout.write(f"Risk: {risk}%\n")
          fout.write(f"Status: {result}\n\n")
            
          push_scan(
                msg=i.strip(),
                risk=risk,
                verdict=verdict(risk),
                date=datetime.datetime.now().strftime("%d %b %Y, %I:%M:%S %p")
            )
          insert_scan_log(
              date=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
              msg=i.strip(),
              risk=risk,
              verdict=verdict(risk)
            )

      print("Bulk Scan Completed..... See Report in ScamMessages.txt.")
            
  except FileNotFoundError:
    print("Error: File Not Found!!")
        