from detector import detection
from database import connection, fetch_domain, fetch_keywords, fetch_scan_log, insert_keywords,insert_domain
from sessionNavigation import pop_scan,peek_scan
from utils import show_banner, show_menu
from bulkScanner import scanBulk

def main():
  print()
  choice = input("::").lower()
  print()

  if choice == '1':
    detection()
    
  elif choice == '2':
    scan = peek_scan()
    for key,value in scan.items():
      print(f"{key} : {value}")
      
  elif choice == '3':
    scan = pop_scan()
    for key,value in scan.items():
      print(f"{key} : {value}")
      
  elif choice == '4':
    for i in fetch_scan_log():
      print(f"{'DateTime ':<12}: {i[1]}")
      print(f"{'Message ':<12}: {i[2]}")
      print(f"{'Risk% ':<12}: {i[3]}")
      print(f"{'Status ':<12}: {i[4]}","\n")
      
  elif choice == '5':
    print('1.Keyword\n2.Domain/Email')
    user_choice = input("::")
    
    if user_choice == '1':
      keyword = input("Enter Keyword: ")
      risk = int(input("Enter Risk Weight: "))
      insert_keywords(keyword=keyword,risk=risk)
      
    elif user_choice == '2':
      domain = input("Enter Domain/Email: ")
      risk = int(input("Enter Risk Weight: "))
      insert_domain(domain=domain,risk=risk)
      
    else:
      print("Not a Valid Option!")
      
  elif choice == '6':
    domains = fetch_domain()
    
    print( '='*83)
    print(f"| {'BlackListed Domain':<65} | {'Risk Weight':<12}| ")
    print( '='*83)
    
    for i in domains:
      print(f"| {i[0]:<65} | {i[1]:<12}| ")
    print( '='*83)
    print("Total Blacklisted Domains: "+str(len(domains)))
    
  elif choice == '7':
    keywords = fetch_keywords()
           
    print( "=" * 66)
    print(f"| {'Scam Keyword':<45} | {'Risk Weight':<14} |")
    print("=" * 66)
    
    for i in keywords:
        print(f"| {i[0]:<45} | {i[1]:<14} |")
        
    print("=" * 66)
    print(f"Total Scam Keywords: {len(keywords)}\n")

  elif choice == '8':
    print("Export to csv ... coming soon!")
    
  elif choice == 'menu':
    show_menu()

  elif choice == 'exit':
    return False

  elif choice == 'a1':
    path = input("Give File Path: ")
    scanBulk(path=path)
    
  else:
    print("Please Enter Valid Option!")


def run_program():
  show_banner()

  if not connection():
    print("Couldn't Run The Program..... MySql Server Not Connected")
    return
  show_menu()
  while True:
    try:
      stop = main()
      if stop is not None:
        break
    except KeyboardInterrupt:
      print("\nExiting The Program... Goodbye!")
      break

run_program()