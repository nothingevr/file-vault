from database import fetch_domain, fetch_keywords, insert_scan_log,connection
from sessionNavigation import push_scan
import datetime
from utils import cleanMessage


# This Function Will Return Status of Message
def verdict(risk):
  if risk <= 30:
    return "Safe"
  elif risk <= 65:
    return "Suspicious"
  else:
    return "Dangerous"


def evaluateMsg(msg):
  connection()
  risk_point = 0
  suspiciousTags = []
  
  for i in fetch_domain():
    if i[0] in msg:
      suspiciousTags.append(i[0])
      risk_point += i[1]
      
  for i in fetch_keywords():
    if i[0] in msg:
      suspiciousTags.append(i[0])
      risk_point += i[1]
      
  risk=min(risk_point,100) # Making Sure Risk Score Doesn't Exceed 100

  return suspiciousTags,risk,verdict(risk)
  
  
# This Function Will Detect Scam Messages 
def detection():
  
  print("Enter the Suspicious Message: ","-----------------------------",sep='\n')
  msg = input('::').lower()
  msg = cleanMessage(msg=msg)
  print()
  
  suspiciousTags, risk, result = evaluateMsg(msg)

  print("Suspicious Keyword/Links Found: ")
  for i in suspiciousTags:
    print(i)
    
  print("=" * 35)
  print(f"Risk Score : {risk}%")
  print(f"Verdict    : {result}")
  print("=" * 35)

  push_scan(
    msg=msg,
    risk=risk,
    verdict=verdict(risk),
    date=datetime.datetime.now().strftime("%d %b %Y, %I:%M:%S %p")
        )
  insert_scan_log(
    date=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    msg=msg,
    risk=risk,
    verdict=verdict(risk)
        )
  
