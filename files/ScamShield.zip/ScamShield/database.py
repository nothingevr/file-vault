import mysql.connector as sql

# Establishing Connection To Mysql Server
def connection():
  try:
    global db
    db = sql.connect( user = 'nothing',
                      host = 'localhost',
                      password = 'admin',
                      database = 'scamshield_db'
    )
    global cur
    cur = db.cursor()
    return True
  except:
    print("Couldn't Connect To Server")
    return False



# This Function will Fetch All The Blacklisted Domain From Database
def fetch_domain():
   cur.execute("select domain_name,risk_weight from blacklisted_domains")
   blacklisted_domain = cur.fetchall()
   return blacklisted_domain

# This Function will Fetch All The Scam Keywords From Database
def fetch_keywords():
  cur.execute("select keyword,risk_weight from scam_keywords")
  keyword = cur.fetchall()
  return keyword

# This Function will Fetch Previous 5 Scans From Database
def fetch_scan_log():
  cur.execute("select * from scan_logs order by scan_id desc;")
  logs = cur.fetchmany(5)  
  return logs
  
# This Function will Insert Scan To Database
def insert_scan_log(date,msg,risk,verdict):
  query = "insert into scan_logs(scan_date,message_snippet,risk_score,verdict) values(%s,%s,%s,%s)"
  cur.execute(query,(date,msg,risk,verdict))
  db.commit()

# This Function will Insert User Given Keyword To Database
def insert_keywords(keyword,risk):
  query = "insert into scam_keywords(keyword,risk_weight,category) values(%s,%s,%s)"
  cur.execute(query,(keyword,risk,"User Entered"))
  db.commit()

# This Function will Insert User Given Domain To Database
def insert_domain(domain,risk):
  query = "insert into blacklisted_domains(domain_name,risk_weight,threat_type) values(%s,%s,%s)"
  cur.execute(query,(domain,risk,"User Entered"))
  db.commit()
