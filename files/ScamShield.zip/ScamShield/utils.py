def show_banner():
    print("=" * 65)
    print("                .--------------------------.             ")
    print("               /  .-.   SCAMSHIELD   .-.    \\            ")
    print("              |  /   \\              /   \\    |           ")
    print("              | |     |   [ 🛡️ ]    |     |   |           ")
    print("               \\ \\   /              \\   /   /            ")
    print("                `-'--------------------'-'		")
    print("               Phishing & Fraud Link Scanner             ")
    print("=" * 65)
    print("  Developer : Adarsh Verma")
    print("  Subject   : Class XII - Computer Science (083)")
    print("  Database  : MySQL (250+ Verified Threat Rules)")
    print("=" * 65)

def show_menu():
  menu = """
  1    : Scan Message
  2    : View Last Scan Result
  3    : View and Remove Recent Scan
  4    : View Last 5 Scans
  5    : Add New Threat Rule
  6    : View All Blacklisted Domain
  7    : View All Scam Keywords
  8    : Export All Scans in CSV File
  menu : Show this Menu
  exit : Close the Program

  ----------------------
  |  Advanced Options  |
  ----------------------

  A1    : BulkScan
  """
  print("\n","*-"*32,"\n",menu,"\n","*-"*32,"\n")


def cleanMessage(msg):
  toBeRemoved = ['!', '?', ',', ';', ':', '"', "'", '(', ')', '[', ']', '{', '}', '₹', '$']

  message = ''
  for i in msg:
    if i not in toBeRemoved:
      message += i
    else:
      message += ' '
  
  return ' '.join(message.split())

